# skincompression
This project aims to let users to upload their skin and compress it into a MCPACK 
